#!/usr/bin/python

print "2+2 = 4!"
