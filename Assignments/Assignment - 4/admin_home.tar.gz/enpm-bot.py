import time, urllib2


while True:
	try:
		response = urllib2.urlopen('http://www.advancedengineering.umd.edu/enpm687-rocks')
		time.sleep(2)

	except:
		pass


