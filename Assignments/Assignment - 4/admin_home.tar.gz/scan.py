#!/usr/bin/python

import socket, sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

def scan(ip):
	try:
		print "trying " + ip
		con = s.connect((ip,22))
		return True
	except:
		return False


for x in range (256):
	ip = sys.argv[1] + "." + str(x)
	if scan(ip):
		print "port 22 open on" + ip
		
